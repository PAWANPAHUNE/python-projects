import pandas as pd
import numpy as np
import scipy.stats as sp

def rm_main(rm_main_input):
    # Convert binary features to int64
    rm_main_input['diabetesMed'] = rm_main_input['diabetesMed'].astype('int64')
    rm_main_input['change'] = rm_main_input['change'].astype('int64')

    # Convert nominal features to int64
    nominal_features = ['metformin', 'repaglinide', 'nateglinide', 'chlorpropamide',
                        'glimepiride', 'acetohexamide', 'glipizide', 'glyburide',
                        'tolbutamide', 'pioglitazone', 'rosiglitazone', 'acarbose',
                        'miglitol', 'troglitazone', 'tolazamide', 'insulin',
                        'glyburide-metformin', 'glipizide-metformin',
                        'glimepiride-pioglitazone', 'metformin-rosiglitazone',
                        'metformin-pioglitazone', 'A1Cresult']
    rm_main_input[nominal_features] = rm_main_input[nominal_features].astype('int64')

    # Convert primary_diag to int
    rm_main_input['primary_diag'] = rm_main_input['primary_diag'].astype('int')

    # Define keys for z-score filtering (removing patient_service and med_change)
    key_columns = ['num_med', 'number_emergency', 'num_lab_procedures',
                   'time_in_hospital', 'num_procedures', 'number_diagnoses',
                   'number_outpatient', 'num_medications', 'number_inpatient']

    # Remove outliers based on z-score
    rm_main_input_filtered = rm_main_input[(np.abs(sp.stats.zscore(rm_main_input[key_columns])) < 3).all(axis=1)]

    # Create dummy variables for nominal columns
    train_dummies = pd.get_dummies(rm_main_input_filtered, columns=['race', 'gender', 'admission_type_id',
                                                                   'discharge_disposition_id', 'admission_source_id',
                                                                   'max_glu_serum', 'A1Cresult', 'primary_diag'],
                                    drop_first=True)

    # Create lists for new nominal and numerical columns
    nom_cols = ['race', 'gender', 'admission_type_id', 'discharge_disposition_id',
                'admission_source_id', 'max_glu_serum', 'A1Cresult', 'primary_diag']

    # Get numeric columns excluding specific columns
    num_cols = list(set(train_dummies.select_dtypes(include='number').columns) - {'readmitted', 'change'})

    # Create a new list for nominal columns based on dummy columns
    nom_cols_new = []
    for col in nom_cols:
        for dummy_col in train_dummies.columns:
            if col in dummy_col:
                nom_cols_new.append(dummy_col)

    # Return cleaned and transformed DataFrame
    return train_dummies

