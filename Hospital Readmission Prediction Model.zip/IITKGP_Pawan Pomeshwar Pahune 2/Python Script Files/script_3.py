def rm_main(rm_main_input):
    import pandas as pd
    import numpy as np
    import seaborn as sns
    import matplotlib.pyplot as plt

    # Convert input data to DataFrame
    train = rm_main_input.copy()

    # List of numeric columns
    num_col = [
        'number_diagnoses', 'num_med', 'num_medications', 'num_lab_procedures',
        'time_in_hospital', 'number_outpatient', 'number_inpatient',
        'number_emergency', 'num_procedures'
    ]

    # Standardize function
    def standardize(data):
        return (data - np.mean(data, axis=0)) / np.std(data, axis=0)

    # Apply standardization
    train[num_col] = standardize(train[num_col])

    # Drop specified columns
    train.drop(['med_change', 'patient_service'], axis=1, inplace=True, errors='ignore')

    # Drop columns with 'unnamed'
    train.drop(train.columns[train.columns.str.contains('unnamed', case=False)], axis=1, inplace=True)

    # Calculate correlation matrix
    train_col = train.corr()

    

    # Find top k correlations with 'readmitted'
    k = 15
    cols = train_col.nlargest(k, 'readmitted')['readmitted'].index
    cm = np.corrcoef(train[cols].values.T)

    

    return train
