def rm_main(rm_main_input):
    import pandas as pd
    import numpy as np

    # Convert input to DataFrame
    train = rm_main_input

    # List of columns to check for skewness and transform
    key = [
        'num_med', 'number_emergency', 'num_lab_procedures',
        'time_in_hospital', 'num_procedures', 'number_diagnoses',
        'number_outpatient', 'num_medications', 'number_inpatient'
    ]

    # Apply log transformation to skewed columns
    for col in key:
        if col in train.columns and pd.api.types.is_numeric_dtype(train[col]):
            if abs(train[col].skew()) >= 1:
                # Replace or handle missing values if needed before log transformation
                train[col].fillna(0, inplace=True)
                train[col + "_log"] = np.log1p(train[col])

    # Display the modified DataFrame
    print(train)

    return train
